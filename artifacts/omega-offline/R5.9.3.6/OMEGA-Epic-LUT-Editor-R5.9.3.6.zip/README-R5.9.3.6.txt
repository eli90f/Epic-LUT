OMEGA Epic LUT Editor R5.9.3.6

Run OMEGA Epic LUT Editor R5.9.3.6.exe.
The editor detects Steam libraries. Select HD2 folder can change the installation.
Cache is created in lut-editor-cache beside the EXE. Logs stay beside the EXE.
See PATCH-NOTES-R5.9.3.6.md and OUTFIT-PREVIEW-TEST.md for current preview limits.
This package contains no game files. Source assets and the salute pose are read from your installation.
